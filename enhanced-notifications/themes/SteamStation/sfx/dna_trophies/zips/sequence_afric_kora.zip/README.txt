Mood: Earthen African Heritage II
Category: Sacred Kora & Gourd
3 Variations: PS4 Chime (~0.95s), PS5 Bloom (~1.40s), PS5 Platinum (~2.20s)
100% Procedural DSP Audio