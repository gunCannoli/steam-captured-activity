Mood: 8-Bit Temple Gong
Category: NES 2A03 Tam-Tam Crash
3 Variations: PS4 Chime (~0.95s), PS5 Bloom (~1.40s), PS5 Platinum (~2.20s)
100% Procedural DSP Audio