Mood: 8-Bit Glockenspiel
Category: NES 2A03 Steel Bar Sparkle
3 Variations: PS4 Chime (~0.95s), PS5 Bloom (~1.40s), PS5 Platinum (~2.20s)
100% Procedural DSP Audio