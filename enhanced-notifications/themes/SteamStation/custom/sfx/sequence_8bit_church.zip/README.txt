Mood: 8-Bit Church Bell
Category: NES 2A03 Cathedral Campanile
3 Variations: PS4 Chime (~0.95s), PS5 Bloom (~1.40s), PS5 Platinum (~2.20s)
100% Procedural DSP Audio